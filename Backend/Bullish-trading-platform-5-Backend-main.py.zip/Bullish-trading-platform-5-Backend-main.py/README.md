# Bullish-trading-platform-5
Automated stock screener and trading backend using fastApi., Alpaca and Plaid
